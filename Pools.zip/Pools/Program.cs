// =============================================================================
//  P O O L S
//  廃プールを歩き続けるゲーム。何かが追ってくる。
//
//  3D furniture:
//    Lockers = full-height wall cells (WallChanging texture = metal locker doors)
//    Benches = cell type-2 "low walls" rendered at partial height by raycaster
//
//  Requirements : .NET 8, Windows
//  Build        : dotnet run
// =============================================================================
#nullable enable
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Media;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Pools;

// =============================================================================
//  ENUMS & STRUCTS
// =============================================================================
public enum PoolZone : byte { Deck=0, Basin=1, Walkway=2, Changing=3, Deep=4 }
public enum SprType   : byte { LifeRing=0, Bench=1, WetFloor=2, TrashCan=3, Locker=4, LanePost=5 }

public readonly struct Sprite
{
    public readonly float X, Y; public readonly SprType Type;
    public Sprite(float x, float y, SprType t) { X=x; Y=y; Type=t; }
}

// =============================================================================
//  ENTITY666
// =============================================================================
public class Entity666
{
    public float X, Y; public bool Active;
    float Speed(float d) => d<3.5f?3.1f:d<8f?2.3f:1.5f;

    public void Spawn(PoolMap map, float px, float py, Random rng)
    {
        for(int i=0;i<2000;i++)
        {
            int ex=rng.Next(3,PoolMap.W-3), ey=rng.Next(3,PoolMap.H-3);
            if(map.IsWall(ex,ey)) continue;
            float dx=ex-px, dy=ey-py;
            if(dx*dx+dy*dy>900f){X=ex+.5f;Y=ey+.5f;Active=true;return;}
        }
        X=PoolMap.W-5;Y=PoolMap.H-5;Active=true;
    }
    public void Update(float dt, PoolMap map, float px, float py)
    {
        if(!Active)return;
        float dx=px-X,dy=py-Y,d=MathF.Sqrt(dx*dx+dy*dy);
        if(d<.4f)return;
        float s=Speed(d)*dt; dx/=d;dy/=d;
        const float M=.30f;
        bool okX=!map.IsWall((int)(X+dx*s+MathF.Sign(dx)*M),(int)Y);
        bool okY=!map.IsWall((int)X,(int)(Y+dy*s+MathF.Sign(dy)*M));
        if(okX)X+=dx*s; if(okY)Y+=dy*s;
        if(!okX&&!okY){
            float ss=s;
            if(!map.IsWall((int)(X+ss+M),(int)Y))X+=ss;
            else if(!map.IsWall((int)(X-ss-M),(int)Y))X-=ss;
            else if(!map.IsWall((int)X,(int)(Y+ss+M)))Y+=ss;
            else if(!map.IsWall((int)X,(int)(Y-ss-M)))Y-=ss;
        }
    }
    public float DistTo(float px,float py){float dx=X-px,dy=Y-py;return MathF.Sqrt(dx*dx+dy*dy);}
}

// =============================================================================
//  TEXTURE GENERATOR
//  tex[0-4]  walls         (by PoolZone)
//  tex[5-9]  floors        (by PoolZone)
//  tex[10-14] ceilings     (by PoolZone)
//  tex[15-20] sprites      (SprType 0-5)
//  tex[21]   bench face    (for low-wall rendering)
// =============================================================================
public static class TexGen
{
    public const int S=64, SS=S*S;

    public static int[][] Build()
    {
        var t=new int[22][];
        // Walls
        t[0]=WallDeck(); t[1]=WallBasin(); t[2]=WallWalkway();
        t[3]=WallChanging(); t[4]=WallDeep();
        // Floors
        t[5]=FloorDeck(); t[6]=FloorBasin(); t[7]=FloorWalkway();
        t[8]=FloorChanging(); t[9]=FloorDeep();
        // Ceilings
        t[10]=CeilDeck(); t[11]=CeilBasin(); t[12]=CeilWalkway();
        t[13]=CeilChanging(); t[14]=CeilDeep();
        // Sprites
        t[15]=SprLifeRing(); t[16]=SprBench(); t[17]=SprWetFloor();
        t[18]=SprTrashCan(); t[19]=SprLocker(); t[20]=SprLanePost();
        // Low-wall bench face
        t[21]=BenchFace();
        return t;
    }

    // ── Entity texture loader ────────────────────────────────────────────────
    public static int[] LoadEntityTex(string path)
    {
        var t=new int[SS];
        try
        {
            using var orig=new Bitmap(path);
            using var sc=new Bitmap(orig,new Size(S,S));
            var bd=sc.LockBits(new Rectangle(0,0,S,S),ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb);
            unsafe
            {
                byte* src=(byte*)bd.Scan0; int stride=bd.Stride;
                int maxL=1;
                for(int y=0;y<S;y++) for(int x=0;x<S;x++)
                {
                    byte* p=src+y*stride+x*4;
                    int l=(p[2]*77+p[1]*150+p[0]*29)>>8;
                    if(l>maxL)maxL=l;
                }
                for(int y=0;y<S;y++) for(int x=0;x<S;x++)
                {
                    byte* p=src+y*stride+x*4;
                    int l=(p[2]*77+p[1]*150+p[0]*29)>>8;
                    if(l<8)continue;
                    int nr=Math.Min(255,p[2]*255/maxL);
                    int ng=Math.Min(255,p[1]*255/maxL);
                    int nb=Math.Min(255,p[0]*255/maxL);
                    t[y*S+x]=unchecked((int)(0xFF000000u|((uint)nr<<16)|((uint)ng<<8)|(uint)nb));
                }
            }
            sc.UnlockBits(bd);
        }
        catch { MakeFallbackFace(t); }
        int vis=0; for(int i=0;i<SS;i++) if(t[i]!=0)vis++;
        if(vis<100)MakeFallbackFace(t);
        return t;
    }

    static void MakeFallbackFace(int[] t)
    {
        int cx=S/2,cy=S/2;
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        {
            float dx=x-cx,dy=y-cy,d=MathF.Sqrt(dx*dx+dy*dy);
            if(d>S/2f-2)continue;
            int v=(int)(200-d*3);
            bool eye=(MathF.Abs(dx-11)<5&&MathF.Abs(dy+8)<5)||(MathF.Abs(dx+11)<5&&MathF.Abs(dy+8)<5);
            bool mouth=dy>10&&dy<20&&MathF.Abs(dx)<18&&(dy<12||MathF.Abs(MathF.Abs(dx)-14)<4);
            if(eye||mouth)v=20;
            t[y*S+x]=Px(v,v,v);
        }
    }

    static int Px(int r,int g,int b)
    {
        if(r<0)r=0;else if(r>255)r=255;
        if(g<0)g=0;else if(g>255)g=255;
        if(b<0)b=0;else if(b>255)b=255;
        return unchecked((int)(0xFF000000u|((uint)r<<16)|((uint)g<<8)|(uint)b));
    }

    // ── WALLS ────────────────────────────────────────────────────────────────
    static int[] WallDeck()
    {
        var t=new int[SS]; var rng=new Random(100);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        {
            int r=228+rng.Next(-6,6),g=222+rng.Next(-6,6),b=212+rng.Next(-6,6);
            if(x%16==0||y%16==0){r-=38;g-=36;b-=32;}
            else{double tx=(x%16)-7.5,ty=(y%16)-7.5;int hi=(int)((1-Math.Sqrt(tx*tx+ty*ty)/10)*14);r+=hi;g+=hi;b+=hi;}
            t[y*S+x]=Px(r,g,b);
        }
        return t;
    }
    static int[] WallBasin()
    {
        var t=new int[SS]; var rng=new Random(101);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        {
            int r=62+rng.Next(-8,8),g=142+rng.Next(-10,10),b=192+rng.Next(-10,10);
            if(x%8==0||y%8==0){r-=18;g-=28;b-=32;}
            else{double gl=Math.Sin(x*.7+.3)*Math.Cos(y*.65+.2)*.4;r+=(int)(gl*18);g+=(int)(gl*20);b+=(int)(gl*16);}
            float st=y/(float)S;g+=(int)(st*8);r-=(int)(st*4);
            t[y*S+x]=Px(r,g,b);
        }
        return t;
    }
    static int[] WallWalkway()
    {
        var t=new int[SS]; var rng=new Random(102);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int v=232+rng.Next(-6,6); if(x%4==0||y%4==0)v-=48; if(x%19==7&&y>15)v-=14; t[y*S+x]=Px(v,v+2,v-2); }
        return t;
    }

    // ── WallChanging: 金属製ロッカー扉（本物らしい3D外観）──────────────────
    static int[] WallChanging()
    {
        var t=new int[SS]; var rng=new Random(103);
        const int LW=12; // ロッカー1枚の幅(px)
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        {
            int lx=x%LW; // ロッカー内X座標
            // フレーム(枠)
            bool frame=(lx==0||lx==LW-1||y==0||y==S-1);
            int r=frame?118:172; int g=frame?120:175; int b=frame?125:180;
            // ノイズ
            r+=rng.Next(-4,4); g+=rng.Next(-4,4); b+=rng.Next(-4,4);
            // 扉の光沢ライン
            if(lx==2||lx==3){r+=18;g+=18;b+=20;}
            // 通気孔スリット
            bool vent=(y>=5&&y<=10&&y%2==0&&lx>2&&lx<LW-3);
            if(vent){r-=55;g-=55;b-=50;}
            // ハンドル(右側中央)
            bool handle=(lx>=LW-4&&lx<=LW-3&&y>=S/2-4&&y<=S/2+4);
            if(handle){r=210;g=195;b=130;} // 真鍮色
            // 番号プレート(右上)
            bool plate=(lx>=LW-5&&lx<=LW-2&&y>=14&&y<=20);
            if(plate){r=230;g=225;b=205;}
            // 下部キックプレート
            if(y>=S-5){r-=25;g-=25;b-=22;}
            t[y*S+x]=Px(r,g,b);
        }
        return t;
    }

    static int[] WallDeep()
    {
        var t=new int[SS]; var rng=new Random(104);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        {
            int r=20+rng.Next(-4,4),g=44+rng.Next(-7,7),b=88+rng.Next(-9,9);
            if(x%16==0||y%16==0){r-=8;g-=12;b-=18;}
            else{double gl=Math.Sin(x*.5+.3)*Math.Cos(y*.48+.2)*.35;b+=(int)(gl*28);g+=(int)(gl*14);r+=(int)(gl*4);}
            t[y*S+x]=Px(r,g,b);
        }
        return t;
    }

    // ── FLOORS ───────────────────────────────────────────────────────────────
    static int[] FloorDeck()
    {
        var t=new int[SS]; var rng=new Random(200);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int v=185+rng.Next(-10,10); if(x%12==0||y%12==0)v-=26; int bx=x%6-3,by=y%6-3; if(bx*bx+by*by<3)v+=8; t[y*S+x]=Px(v,v+3,v+5); }
        return t;
    }
    static int[] FloorBasin()
    {
        var t=new int[SS]; var rng=new Random(201);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int r=28+rng.Next(-5,5),g=105+rng.Next(-12,12),b=175+rng.Next(-12,12); double cx=Math.Sin(x*.9+.4)*Math.Cos(y*.8+.6)*.5; r+=(int)(cx*22);g+=(int)(cx*28);b+=(int)(cx*20); if(x%6==0||y%6==0){r-=12;g-=18;b-=24;} t[y*S+x]=Px(r,g,b); }
        return t;
    }
    static int[] FloorWalkway()
    {
        var t=new int[SS]; var rng=new Random(202);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int v=210+rng.Next(-8,8); if(x%6==0||y%6==0)v-=38; t[y*S+x]=Px(v,v,v-4); }
        return t;
    }
    static int[] FloorChanging()
    {
        var t=new int[SS]; var rng=new Random(203);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int r=200+rng.Next(-10,10),g=192+rng.Next(-10,10),b=174+rng.Next(-10,10); if(x%8==0||y%8==0){r-=24;g-=22;b-=18;} t[y*S+x]=Px(r,g,b); }
        return t;
    }
    static int[] FloorDeep()
    {
        var t=new int[SS]; var rng=new Random(204);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int r=10+rng.Next(-4,4),g=22+rng.Next(-6,6),b=48+rng.Next(-8,8); if(x%8==0||y%8==0){r-=5;g-=8;b-=14;} t[y*S+x]=Px(r,g,b); }
        return t;
    }

    // ── CEILINGS ─────────────────────────────────────────────────────────────
    static int[] CeilDeck()
    {
        var t=new int[SS]; var rng=new Random(300);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int v=235+rng.Next(-6,6); bool fr=x%24==0||y%24==0||x%24>=22||y%24>=22; if(fr)v-=40; else{int px=x%24,py=y%24;if(px>=3&&px<=20&&py>=9&&py<=14)v=Math.Min(255,v+28);} t[y*S+x]=Px(v-2,v-2,v-8); }
        return t;
    }
    static int[] CeilBasin()
    {
        var t=new int[SS]; var rng=new Random(301);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int r=195+rng.Next(-6,6),g=218+rng.Next(-6,6),b=232+rng.Next(-6,6); bool fr=x%24==0||y%24==0||x%24>=22||y%24>=22; if(fr){r-=40;g-=42;b-=45;} else{int px=x%24,py=y%24;if(px>=3&&px<=20&&py>=9&&py<=14){r=Math.Min(255,r+35);g=Math.Min(255,g+30);b=Math.Min(255,b+22);}} double c=Math.Sin(x*.9+.5)*Math.Cos(y*.85+.7)*.4; r+=(int)(c*20);g+=(int)(c*22);b+=(int)(c*18); t[y*S+x]=Px(r,g,b); }
        return t;
    }
    static int[] CeilWalkway()
    {
        var t=new int[SS]; var rng=new Random(302);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int v=200+rng.Next(-12,12); v+=(int)(Math.Sin(x*.22)*Math.Cos(y*.21)*8); t[y*S+x]=Px(v,v-2,v-6); }
        return t;
    }
    static int[] CeilChanging()
    {
        var t=new int[SS]; var rng=new Random(303);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int v=222+rng.Next(-7,7); if(x%16==0||y%16==0)v-=34; int px=x%8-4,py=y%8-4; if(px*px+py*py<4)v-=18; t[y*S+x]=Px(v-1,v-1,v-10); }
        return t;
    }
    static int[] CeilDeep()
    {
        var t=new int[SS]; var rng=new Random(304);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { int r=30+rng.Next(-5,5),g=60+rng.Next(-8,8),b=110+rng.Next(-10,10); double c=Math.Sin(x*1.1+.4)*Math.Cos(y*1.0+.6)*.45; r+=(int)(c*28);g+=(int)(c*32);b+=(int)(c*26); if(x%24==0||y%24==0){r-=10;g-=14;b-=20;} t[y*S+x]=Px(r,g,b); }
        return t;
    }

    // ── SPRITE TEXTURES ──────────────────────────────────────────────────────
    static int[] SprLifeRing()
    {
        var t=new int[SS]; int cx=S/2; float or2=S/2f-3f,ir=S/3.5f;
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { float dx=x-cx,dy=y-cx,d=MathF.Sqrt(dx*dx+dy*dy); if(d<ir-2||d>or2+1)continue; if(d<ir+1||d>or2-1){t[y*S+x]=Px(40,35,30);continue;} float ang=MathF.Atan2(dy,dx);if(ang<0)ang+=2*MathF.PI;int q=(int)(ang/(MathF.PI/2f))&3; t[y*S+x]=(q&1)==0?Px(215,62,28):Px(242,240,236); }
        return t;
    }
    static int[] SprBench()
    {
        var t=new int[SS];
        void VR(int x0,int y0,int x1,int y1,int r,int g,int b){for(int yy=y0;yy<=y1;yy++)for(int xx=x0;xx<=x1;xx++)if((uint)xx<S&&(uint)yy<S)t[yy*S+xx]=Px(r,g,b);}
        VR(8,28,12,58,150,148,145);VR(51,28,55,58,150,148,145);VR(8,46,55,48,130,128,125);
        int[]sl={22,30,38};foreach(int sy in sl){var r2=new Random(sy);VR(6,sy,57,sy+6,138+r2.Next(-10,10),95+r2.Next(-8,8),52+r2.Next(-6,6));}
        for(int i=0;i<3;i++){int sy=sl[i];for(int xx=8;xx<56;xx+=7)VR(xx,sy+1,xx+1,sy+5,115,78,40);}
        return t;
    }
    static int[] SprWetFloor()
    {
        var t=new int[SS]; int cx=S/2;
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        { if(Math.Abs(x-cx)+Math.Abs(y-cx)>28)continue; if(Math.Abs(x-cx)+Math.Abs(y-cx)>25){t[y*S+x]=Px(40,35,25);continue;} t[y*S+x]=(x+y)%10<4?Px(30,28,22):Px(228,195,28); }
        return t;
    }
    static int[] SprTrashCan()
    {
        var t=new int[SS];
        for(int y=10;y<58;y++){ float tp=y<20?(y-10)/10f:1f;int hw=(int)(22*tp),cx=S/2;for(int x=cx-hw;x<=cx+hw;x++){if((uint)x>=S)continue;bool sd=x==cx-hw||x==cx+hw,lid=y>=10&&y<=14&&!sd;int r=lid?145:sd?100:132,g=lid?143:sd?98:130,b=lid?140:sd?95:127;if(x==cx+6||x==cx+7){r+=30;g+=30;b+=30;}t[y*S+x]=Px(r,g,b);}}
        return t;
    }
    static int[] SprLocker()
    {
        var t=new int[SS];
        for(int y=2;y<S-2;y++)for(int x=4;x<S-4;x++){bool bd=x<=5||x>=S-6||y<=3||y>=S-3;int v=bd?115:175;if(x==10||x==11)v+=22;t[y*S+x]=Px(v,v+2,v+4);}
        for(int i=0;i<5;i++){int sy=8+i*4;for(int x=10;x<S-10;x++)t[sy*S+x]=Px(60,62,68);}
        for(int y=30;y<=36;y++)for(int x=S-14;x<=S-10;x++)if((uint)x<S&&(uint)y<S)t[y*S+x]=Px(195,188,165);
        return t;
    }
    static int[] SprLanePost()
    {
        var t=new int[SS]; int cx=S/2;
        for(int y=4;y<S-2;y++)for(int x=cx-4;x<=cx+4;x++){if((uint)x>=S)continue;bool sd=x==cx-4||x==cx+4,wh=(y/8)%2==0;t[y*S+x]=sd?Px(20,20,20):wh?Px(235,235,240):Px(30,100,200);}
        for(int y=S-8;y<S-1;y++)for(int x=cx-9;x<=cx+9;x++)if((uint)x<S)t[y*S+x]=Px(50,50,52);
        return t;
    }

    // ── BENCH FACE (低壁レンダリング用) ─────────────────────────────────────
    // 木製ベンチを横から見た断面テクスチャ
    // 上部: 座面(明るい木目) / 中部: 前面パネル(横桟) / 下部: 金属脚
    static int[] BenchFace()
    {
        var t=new int[SS]; var rng=new Random(600);
        for(int y=0;y<S;y++) for(int x=0;x<S;x++)
        {
            if(y<3)
            {
                // 座面(トップ) - やや明るい木
                int r=168+rng.Next(-8,8),g=125+rng.Next(-8,8),b=68+rng.Next(-6,6);
                if(x%10<2)r-=12;  // 桟の継ぎ目
                t[y*S+x]=Px(r,g,b);
            }
            else if(y<S-8)
            {
                // 前面板 - 木目と横桟
                int r=138+rng.Next(-8,8),g=98+rng.Next(-8,8),b=52+rng.Next(-6,6);
                if((y-3)%10<2){r-=22;g-=18;b-=12;} // 横桟ライン
                if((x*3+(y-3))%13==0){r-=12;g-=10;} // 木目
                t[y*S+x]=Px(r,g,b);
            }
            else
            {
                // 金属脚
                bool leg=(x<8||x>S-9);
                int v=leg?(115+rng.Next(-5,5)):(80+rng.Next(-5,5));
                t[y*S+x]=Px(v,v,v+5);
            }
        }
        return t;
    }
}

// =============================================================================
//  MAP
//  Cell types: 0=open  1=full wall  2=low wall(bench)
// =============================================================================
public class PoolMap
{
    public const int W=220, H=220;
    public byte[,]      Cells  =new byte[W,H];
    public byte[,]      Zones  =new byte[W,H];
    public List<Sprite> Sprites=new();
    public int   StartX=W/2, StartY=H/2;
    public float StartAngle=0f;

    readonly record struct Pool(int X,int Y,int PW,int PH,bool IsDeep);

    // 0=open, 1=full wall, 2=bench low-wall
    public byte GetCell(int x,int y)
    {
        if((uint)x>=W||(uint)y>=H)return 1;
        return Cells[x,y];
    }

    // プレイヤー衝突判定 (type 1 も 2 も通り抜け不可)
    public bool IsWall(int x,int y)
    {
        if((uint)x>=W||(uint)y>=H)return true;
        return Cells[x,y]!=0;
    }

    public PoolZone GetZone(double x,double y)
    {
        int ix=(int)x,iy=(int)y;
        if((uint)ix>=W||(uint)iy>=H)return PoolZone.Deck;
        return(PoolZone)Zones[ix,iy];
    }

    // ─────────────────────────────────────────────────────────────────────────
    public void Generate(int seed=42)
    {
        var rng=new Random(seed);
        for(int y=0;y<H;y++) for(int x=0;x<W;x++){Cells[x,y]=1;Zones[x,y]=(byte)PoolZone.Deck;}

        var pools=new List<Pool>();
        int att=0;
        while(pools.Count<12&&att<600)
        {
            att++;
            int pw=rng.Next(10,26),ph=rng.Next(6,18),px=rng.Next(10,W-pw-10),py=rng.Next(10,H-ph-10);
            bool deep=rng.Next(6)==0;
            bool ok=true;
            for(int dy=-6;dy<ph+6&&ok;dy++) for(int dx=-6;dx<pw+6&&ok;dx++)
            {int tx=px+dx,ty=py+dy;if((uint)tx>=W||(uint)ty>=H||Cells[tx,ty]==0){ok=false;break;}}
            if(!ok)continue;
            for(int dy=-4;dy<ph+4;dy++) for(int dx=-4;dx<pw+4;dx++)
            {int tx=px+dx,ty=py+dy;if((uint)tx<W&&(uint)ty<H){Cells[tx,ty]=0;Zones[tx,ty]=(byte)PoolZone.Deck;}}
            for(int dy=0;dy<ph;dy++) for(int dx=0;dx<pw;dx++)
            {Cells[px+dx,py+dy]=0;Zones[px+dx,py+dy]=(byte)(deep?PoolZone.Deep:PoolZone.Basin);}
            pools.Add(new Pool(px,py,pw,ph,deep));
        }

        var sorted=pools.OrderBy(p=>p.X+p.Y).ToList();
        for(int i=1;i<sorted.Count;i++){var a=sorted[i-1];var b=sorted[i];Corridor(a.X+a.PW/2,a.Y+a.PH/2,b.X+b.PW/2,b.Y+b.PH/2,3,PoolZone.Walkway);}
        for(int i=0;i<sorted.Count-2;i++){var a=sorted[i];var b=sorted[i+2];Corridor(a.X+a.PW/2,a.Y+a.PH/2,b.X+b.PW/2,b.Y+b.PH/2,2,PoolZone.Walkway);}

        // 更衣室を追加（ベンチ列付き）
        foreach(var pool in pools.Take(5))
        {
            int s2=rng.Next(4),crw=rng.Next(10,16),crh=rng.Next(8,14),crx,cry;
            switch(s2){case 0:crx=pool.X+pool.PW+5;cry=pool.Y;break;case 1:crw=rng.Next(10,16);crx=pool.X-crw-5;cry=pool.Y;break;case 2:crx=pool.X;cry=pool.Y+pool.PH+5;break;default:crx=pool.X;cry=pool.Y-crh-5;break;}
            if(crx<3||crx+crw>=W-3||cry<3||cry+crh>=H-3)continue;
            CarveChangingRoom(crx,cry,crw,crh);
            Corridor(crx+crw/2,cry+crh/2,pool.X+pool.PW/2,pool.Y+pool.PH/2,2,PoolZone.Walkway);
        }

        if(pools.Count>0){var p=pools[0];StartX=p.X+p.PW/2;StartY=p.Y-2;StartAngle=MathF.PI/2f;Ensure(StartX,StartY);}
        PlaceSprites(pools,rng);
    }

    // 更衣室を彫る + ベンチ行を設置
    void CarveChangingRoom(int rx,int ry,int rw,int rh)
    {
        for(int dy=0;dy<rh&&ry+dy<H-1;dy++) for(int dx=0;dx<rw&&rx+dx<W-1;dx++)
        {Cells[rx+dx,ry+dy]=0;Zones[rx+dx,ry+dy]=(byte)PoolZone.Changing;}

        // ベンチ列(type 2) を後方壁の1マス手前に設置
        // ry = 後方壁(ロッカー壁) 、ry+1 = ベンチ列
        if(rh>=5&&rw>=4)
        {
            int benchY=ry+1;
            for(int dx=1;dx<rw-1&&rx+dx<W-1;dx++)
            {
                if((uint)(ry+1)<(uint)H)
                {
                    Cells[rx+dx,benchY]=2;
                    Zones[rx+dx,benchY]=(byte)PoolZone.Changing;
                }
            }
        }
    }

    void Corridor(int x0,int y0,int x1,int y1,int w,PoolZone z)
    {
        bool hf=Math.Abs(x1-x0)>Math.Abs(y1-y0);
        int mx=hf?x1:x0,my=hf?y0:y1;
        void Seg(int ax,int ay,int bx,int by,bool h)
        {
            if(h)for(int x=Math.Min(ax,bx);x<=Math.Max(ax,bx);x++)for(int dw=-w/2;dw<=w/2;dw++)Open(x,ay+dw,z);
            else for(int y=Math.Min(ay,by);y<=Math.Max(ay,by);y++)for(int dw=-w/2;dw<=w/2;dw++)Open(ax+dw,y,z);
        }
        Seg(x0,y0,mx,my,hf);Seg(mx,my,x1,y1,!hf);
    }
    void Open(int x,int y,PoolZone z)
    {
        if((uint)x>=W||(uint)y>=H)return;
        // ベンチ(type2)や壁(type1)で塞がれていたら通路として開く
        if(Cells[x,y]==1){Cells[x,y]=0;}
        // ただし既存のベンチセル(type2)は上書きしない
        var cur=(PoolZone)Zones[x,y];
        if(cur!=PoolZone.Basin&&cur!=PoolZone.Deep)Zones[x,y]=(byte)z;
    }
    void Ensure(int x,int y){for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){int tx=x+dx,ty=y+dy;if((uint)tx<W&&(uint)ty<H){Cells[tx,ty]=0;if((PoolZone)Zones[tx,ty]>PoolZone.Deep)Zones[tx,ty]=(byte)PoolZone.Deck;}}}

    void PlaceSprites(List<Pool> pools,Random rng)
    {
        foreach(var pool in pools)
        {
            TryRing(pool.X+rng.Next(pool.PW),pool.Y-2);
            TryRing(pool.X+rng.Next(pool.PW),pool.Y+pool.PH+1);
            if(pool.PW>14)TryRing(pool.X+rng.Next(pool.PW),pool.Y-2);
            int sp=pool.PW/Math.Max(1,pool.PW/5);
            for(int i=sp;i<pool.PW-sp;i+=sp)TrySpr(pool.X+i+.5f,pool.Y+pool.PH/2f,SprType.LanePost);
        }
        // 通路の壁際にゴミ箱・ウェットフロアサイン
        for(int y=5;y<H-5;y+=8) for(int x=5;x<W-5;x+=8)
        {
            if(Cells[x,y]!=0||(PoolZone)Zones[x,y]!=PoolZone.Walkway)continue;
            bool adjWall=IsWall(x-1,y)||IsWall(x+1,y)||IsWall(x,y-1)||IsWall(x,y+1);
            if(!adjWall)continue;
            if(rng.Next(25)==0)TrySpr(x+.5f,y+.5f,SprType.WetFloor);
        }
    }
    void TryRing(int x,int y){if((uint)x<W&&(uint)y<H&&Cells[x,y]==0)Sprites.Add(new Sprite(x+.5f,y+.5f,SprType.LifeRing));}
    void TrySpr(float x,float y,SprType tp){int ix=(int)x,iy=(int)y;if((uint)ix<W&&(uint)iy<H&&Cells[ix,iy]==0)Sprites.Add(new Sprite(x,y,tp));}
}

// =============================================================================
//  ATMOSPHERE
// =============================================================================
public static class Atmos
{
    public record Fog(int R,int G,int B,float Dist,float LightBase,float CausticStr);
    public static Fog Get(PoolZone z) => z switch
    {
        PoolZone.Deck     => new(210,218,224,15f,.92f,.30f),
        PoolZone.Basin    => new(100,165,210,18f,.88f,.55f),
        PoolZone.Walkway  => new(200,208,212,11f,.82f,.15f),
        PoolZone.Changing => new(208,202,192, 9f,.78f,.05f),
        PoolZone.Deep     => new( 18, 38, 80,16f,.60f,.72f),
        _                 => new(200,205,210,13f,.85f,.25f),
    };
}

// =============================================================================
//  PLAYER
// =============================================================================
public class Player
{
    public float X,Y,Angle,HeadBob,EyeOffset;
    float _bobP;
    public void Init(PoolMap m){X=m.StartX+.5f;Y=m.StartY+.5f;Angle=m.StartAngle;}
    public void Update(float dt,bool[]keys,float mdx,PoolMap map)
    {
        float rot=2.1f*dt;
        if(keys[(int)Keys.Left])Angle-=rot; if(keys[(int)Keys.Right])Angle+=rot;
        Angle+=mdx*.0025f;
        float spd=3.1f*dt,dx=0,dy=0;
        if(keys[(int)Keys.W]||keys[(int)Keys.Up]){dx+=MathF.Cos(Angle);dy+=MathF.Sin(Angle);}
        if(keys[(int)Keys.S]||keys[(int)Keys.Down]){dx-=MathF.Cos(Angle);dy-=MathF.Sin(Angle);}
        if(keys[(int)Keys.A]){dx+=MathF.Sin(Angle);dy-=MathF.Cos(Angle);}
        if(keys[(int)Keys.D]){dx-=MathF.Sin(Angle);dy+=MathF.Cos(Angle);}
        float len=MathF.Sqrt(dx*dx+dy*dy);
        if(len>.01f)
        {
            dx=dx/len*spd;dy=dy/len*spd;
            const float M=.28f;
            if(!map.IsWall((int)(X+dx+(dx>0?M:-M)),(int)Y))X+=dx;
            if(!map.IsWall((int)X,(int)(Y+dy+(dy>0?M:-M))))Y+=dy;
            _bobP+=dt*8f;HeadBob=MathF.Sin(_bobP)*.046f;
        }
        else HeadBob*=.83f;
    }
}

// =============================================================================
//  RAYCASTER
//  壁レンダリングでは cell type-2 (ベンチ) を通過し、部分高さで後描きする
// =============================================================================
public static unsafe class Raycaster
{
    const int T=TexGen.S, TM=T-1;
    static int C8(int v)=>v<0?0:v>255?255:v;
    static float Caustic(float wx,float wy,float t)
    {
        float c=MathF.Sin(wx*1.30f+t*1.85f)*MathF.Cos(wy*1.05f+t*1.50f)
               +MathF.Sin(wx*.65f-wy*.88f+t*2.30f)*.60f
               +MathF.Sin((wx+wy)*1.55f+t*.95f)*.40f
               +MathF.Sin(wx*2.1f+wy*1.8f+t*3.1f)*.20f;
        return .62f+(c/4.4f+.50f)*.76f;
    }
    static int FogBlend(int col,float br,float ff,int fR,int fG,int fB)
    {
        int r=C8((int)(((col>>16)&0xFF)*br));int g=C8((int)(((col>>8)&0xFF)*br));int b=C8((int)((col&0xFF)*br));
        r=(int)(r+(fR-r)*ff);g=(int)(g+(fG-g)*ff);b=(int)(b+(fB-b)*ff);
        return unchecked((int)(0xFF000000u|((uint)C8(r)<<16)|((uint)C8(g)<<8)|(uint)C8(b)));
    }
    static int BlendPx(int a,int b,float t)
    {
        int aR=(a>>16)&0xFF,aG=(a>>8)&0xFF,aB=a&0xFF;
        int bR=(b>>16)&0xFF,bG=(b>>8)&0xFF,bB=b&0xFF;
        return unchecked((int)(0xFF000000u|((uint)(int)(aR+(bR-aR)*t)<<16)|((uint)(int)(aG+(bG-aG)*t)<<8)|(uint)(int)(aB+(bB-aB)*t)));
    }

    public static void Render(
        int* px,int W,int H,
        Player pl,PoolMap map,int[][] tex,int[] entTex,
        float light,float time,PoolZone zone,Entity666 entity)
    {
        var fog=Atmos.Get(zone);
        int fR=fog.R,fG=fog.G,fB=fog.B; float fogDist=fog.Dist,cs=fog.CausticStr;
        double posX=pl.X,posY=pl.Y;
        double dirX=Math.Cos(pl.Angle),dirY=Math.Sin(pl.Angle);
        double plX=-dirY*.66,plY=dirX*.66;
        double eyeH=.5+pl.HeadBob+pl.EyeOffset; int hPx=(int)(eyeH*H);
        double posZF=eyeH*H,posZC=(1.0-eyeH)*H;
        double rdx0=dirX-plX,rdy0=dirY-plY,rdx1=dirX+plX,rdy1=dirY+plY;
        float* zBuf=stackalloc float[W];
        for(int i=0;i<W;i++)zBuf[i]=float.MaxValue;

        // ── Floor / Ceiling ───────────────────────────────────────────────────
        for(int y=0;y<H;y++)
        {
            bool ic=y<hPx;
            double p=ic?(hPx-y):(y-hPx); if(p<.5)p=.5;
            double rd=(ic?posZC:posZF)/p; if(rd>70)rd=70;
            double stX2=rd*(rdx1-rdx0)/W,stY2=rd*(rdy1-rdy0)/W;
            double flX=posX+rd*rdx0,flY=posY+rd*rdy0;
            float ff=(float)Math.Min(1.0,rd/fogDist),br2=light*(1f-ff*.88f);
            int* row=px+y*W;
            for(int x=0;x<W;x++,flX+=stX2,flY+=stY2)
            {
                int txX=(int)((flX-Math.Floor(flX))*T)&TM;
                int txY=(int)((flY-Math.Floor(flY))*T)&TM;
                PoolZone cz=map.GetZone(flX,flY);
                float cbr=br2;
                if(!ic&&(cz==PoolZone.Basin||cz==PoolZone.Deep))
                {
                    float rp=4.5f;
                    txX=((int)((flX-Math.Floor(flX))*T+MathF.Sin((float)flY*.75f+time*2.1f)*rp))&TM;
                    txY=((int)((flY-Math.Floor(flY))*T+MathF.Sin((float)flX*.75f+time*2.4f)*rp))&TM;
                    cbr*=Caustic((float)flX,(float)flY,time)*cs+(1f-cs);
                }
                if(ic&&(cz==PoolZone.Basin||cz==PoolZone.Deep||cz==PoolZone.Deck))
                    cbr*=Caustic((float)flX,(float)flY,time)*cs+(1f-cs);
                int col=tex[ic?10+(int)cz:5+(int)cz][txY*T+txX];
                if(!ic&&(cz==PoolZone.Basin||cz==PoolZone.Deep))
                    col=BlendPx(col,tex[10+(int)cz][txY*T+txX],(float)Math.Min(1.0,rd/6.0)*.45f);
                row[x]=FogBlend(col,cbr,ff,fR,fG,fB);
            }
        }

        // ── Walls + Bench low-walls ───────────────────────────────────────────
        for(int x=0;x<W;x++)
        {
            double camX=2.0*x/W-1.0,rayX=dirX+plX*camX,rayY=dirY+plY*camX;
            int mapX=(int)posX,mapY=(int)posY;
            double ddX=rayX==0?1e30:Math.Abs(1.0/rayX),ddY=rayY==0?1e30:Math.Abs(1.0/rayY);
            double sdX,sdY; int stX2,stY2;
            if(rayX<0){stX2=-1;sdX=(posX-mapX)*ddX;}else{stX2=1;sdX=(mapX+1.0-posX)*ddX;}
            if(rayY<0){stY2=-1;sdY=(posY-mapY)*ddY;}else{stY2=1;sdY=(mapY+1.0-posY)*ddY;}

            // DDA: type-1 で停止、type-2 (ベンチ) は通過して記録
            int side=0; double perp=0;
            bool fullHit=false,benchHit=false;
            double fullPerp=fogDist*2,benchPerp=0;
            int fullMX=mapX,fullMY=mapY,fullSide=0;
            int benchMX=0,benchMY=0,benchSide=0;

            while(true)
            {
                if(sdX<sdY){sdX+=ddX;mapX+=stX2;side=0;perp=sdX-ddX;}
                else{sdY+=ddY;mapY+=stY2;side=1;perp=sdY-ddY;}
                if(perp>fogDist*1.8)break;
                byte cell=map.GetCell(mapX,mapY);
                if(cell==1){fullHit=true;fullMX=mapX;fullMY=mapY;fullSide=side;fullPerp=perp;break;}
                if(cell==2&&!benchHit){benchHit=true;benchMX=mapX;benchMY=mapY;benchSide=side;benchPerp=perp;}
            }

            // ── 通常の壁を描画 ───────────────────────────────────────────────
            if(fullHit)
            {
                zBuf[x]=(float)fullPerp;
                int lH=(int)(H/fullPerp),ds=Math.Max(0,hPx-lH/2),de=Math.Min(H-1,hPx+lH/2);
                PoolZone wz=map.GetZone(fullMX,fullMY); int[]wt=tex[(int)wz];
                double wX=(fullSide==0)?(posY+fullPerp*rayY):(posX+fullPerp*rayX); wX-=Math.Floor(wX);
                int txX2=(int)(wX*T); if((fullSide==0&&rayX>0)||(fullSide==1&&rayY<0))txX2=T-txX2-1;
                txX2=Math.Max(0,Math.Min(TM,txX2));
                double stp=(double)T/lH,txP=(ds-hPx+lH/2.0)*stp;
                float ff2=(float)Math.Min(1.0,fullPerp/fogDist),dk=fullSide==1?.63f:1.0f;
                float br3=dk*light*(1f-ff2*.92f);
                float hwX=(float)(fullSide==0?fullMX:posX+fullPerp*rayX),hwY=(float)(fullSide==1?fullMY:posY+fullPerp*rayY);
                if(wz==PoolZone.Basin||wz==PoolZone.Deep||wz==PoolZone.Deck)
                    br3*=Caustic(hwX,hwY,time)*cs+(1f-cs);
                for(int y=ds;y<=de;y++,txP+=stp)
                    px[y*W+x]=FogBlend(wt[((int)txP&TM)*T+txX2],br3,ff2,fR,fG,fB);
            }
            else zBuf[x]=float.MaxValue;

            // ── ベンチ(低壁)を後描き ─────────────────────────────────────────
            if(benchHit&&benchPerp<(fullHit?fullPerp:fogDist*2))
            {
                zBuf[x]=Math.Min(zBuf[x],(float)benchPerp);
                int lwLH=(int)(H/benchPerp);
                // ベンチは床から高さの約38%
                int lwBot=Math.Min(H-1,hPx+lwLH/2);      // 床ライン
                int lwTop=Math.Max(0,lwBot-(int)(lwLH*.38f)); // ベンチ上面

                double bwX=(benchSide==0)?(posY+benchPerp*rayY):(posX+benchPerp*rayX);
                bwX-=Math.Floor(bwX);
                int bwTX=(int)(bwX*T);
                if((benchSide==0&&rayX>0)||(benchSide==1&&rayY<0))bwTX=T-bwTX-1;
                bwTX=Math.Max(0,Math.Min(TM,bwTX));

                int bwH=Math.Max(1,lwBot-lwTop);
                double bwStp=(double)T/bwH,bwPos=0;
                float bwFog=(float)Math.Min(1.0,benchPerp/fogDist);
                float bwBr=(benchSide==1?.65f:1.0f)*light*(1f-bwFog*.85f);

                int[]bwt=tex[21]; // BenchFace
                for(int y=lwTop;y<=lwBot;y++,bwPos+=bwStp)
                    px[y*W+x]=FogBlend(bwt[((int)bwPos&TM)*T+bwTX],bwBr,bwFog,fR,fG,fB);
            }
        }

        // ── Sprites ───────────────────────────────────────────────────────────
        double invDet=1.0/(plX*dirY-dirX*plY);
        var vis=map.Sprites
            .Select(s=>{double dx2=s.X-posX,dy2=s.Y-posY;
                        // TX = camera-plane lateral coord, TY = depth (distance in front)
                        double tx=invDet*(dirY*dx2-dirX*dy2);
                        double ty=invDet*(-plY*dx2+plX*dy2);
                        return(Spr:s,TX:tx,TY:ty,D2:dx2*dx2+dy2*dy2);})
            .Where(s=>s.TY>.1)                        // TY = depth → must be >0 to be in front
            .OrderByDescending(s=>s.D2).ToList();
        foreach(var(spr,tX,tY,_) in vis)
        {
            // Screen X uses lateral/depth ratio; size scales with 1/depth
            int ssx=(int)((W/2.0)*(1.0+tX/tY)),sprH=Math.Abs((int)(H/tY)),shh=sprH/2;
            int dsx=Math.Max(0,ssx-shh),dex=Math.Min(W-1,ssx+shh),dsy=Math.Max(0,hPx-shh),dey=Math.Min(H-1,hPx+shh);
            if(dsx>dex||dsy>dey)continue;
            int[]st=tex[15+(int)spr.Type]; float ff3=(float)Math.Min(1.0,tY/fogDist),sbr=light*(1f-ff3*.90f);
            double tyO=(dsy-(hPx-shh))*(double)T/sprH,tyS=(double)T/sprH;
            for(int x=dsx;x<=dex;x++){
                if((float)tY>=zBuf[x])continue;       // compare depth to z-buffer
                int etxX=(int)((x-(ssx-shh))*(double)T/sprH);if((uint)etxX>=T)continue;
                double ty3=tyO;
                for(int y=dsy;y<=dey;y++,ty3+=tyS){int etxY=(int)ty3;if((uint)etxY>=T)continue;int col=st[etxY*T+etxX];if(col==0)continue;px[y*W+x]=FogBlend(col,sbr,ff3,fR,fG,fB);}
            }
        }

        // ── Entity666 ─────────────────────────────────────────────────────────
        if(entity.Active)
        {
            double edx=entity.X-posX,edy=entity.Y-posY;
            // Same convention: TX=lateral, TY=depth
            double eTX=invDet*(dirY*edx-dirX*edy);
            double eTY=invDet*(-plY*edx+plX*edy);
            if(eTY>.1)                                 // depth check (was eTX: wrong!)
            {
                int eSSX=(int)((W/2.0)*(1.0+eTX/eTY)); // lateral/depth  (was eTY/eTX)
                int eH=Math.Abs((int)(H/eTY*1.05)),eHH=eH/2; // size from depth (was eTX)
                int eMid=hPx-(int)(H/eTY*.04);
                int dsx=Math.Max(0,eSSX-eHH),dex=Math.Min(W-1,eSSX+eHH);
                int dsy=Math.Max(0,eMid-eHH),dey=Math.Min(H-1,eMid+eHH);
                if(dsx<=dex&&dsy<=dey)
                {
                    float eFog=(float)Math.Min(1.0,eTY/fogDist),eBr=light*(1f-eFog*.72f)*1.10f;
                    float cl=Math.Max(0f,1f-(float)eTY/18f);
                    int aFR=C8(fR+(int)((255-fR)*cl*.45f)),aFG=C8(fG-(int)(fG*cl*.35f)),aFB=C8(fB-(int)(fB*cl*.35f));
                    double tyO2=(dsy-(eMid-eHH))*(double)T/eH,tyS2=(double)T/eH;
                    for(int x=dsx;x<=dex;x++){
                        if((float)eTY>=zBuf[x])continue; // depth vs z-buffer (was eTX)
                        int etxX=(int)((x-(eSSX-eHH))*(double)T/eH);if((uint)etxX>=T)continue;
                        double ty4=tyO2;
                        for(int y=dsy;y<=dey;y++,ty4+=tyS2){
                            int etxY=(int)ty4;if((uint)etxY>=T)continue;
                            int col=entTex[etxY*T+etxX];if(col==0)continue;
                            int r=C8((int)(((col>>16)&0xFF)*eBr*1.60f));
                            int g=C8((int)(((col>>8)&0xFF)*eBr*1.10f));
                            int b=C8((int)((col&0xFF)*eBr*0.80f));
                            r=(int)(r+(aFR-r)*eFog);g=(int)(g+(aFG-g)*eFog);b=(int)(b+(aFB-b)*eFog);
                            px[y*W+x]=unchecked((int)(0xFF000000u|((uint)C8(r)<<16)|((uint)C8(g)<<8)|(uint)C8(b)));
                        }
                    }
                }
            }
        }
    }
}

// =============================================================================
//  AUDIO
// =============================================================================
public static class AudioGen
{
    public static MemoryStream BuildPoolAmbience()
    {
        const int SR=22050,DUR=10; int n=SR*DUR;
        var rng=new Random(55); var sam=new short[n];
        for(int i=0;i<n;i++){double t=(double)i/SR;double s=Math.Sin(2*Math.PI*43*t)*.26+Math.Sin(2*Math.PI*86*t)*.12+Math.Sin(2*Math.PI*120*t)*.09;s*=.92+Math.Sin(2*Math.PI*3.2*t)*.08;s+=(rng.NextDouble()-.5)*.03;double fade=1.0,w=SR*.6;if(i<w)fade=i/w;if(i>n-w)fade=(n-i)/w;sam[i]=(short)(s*fade*11500);}
        var ms=new MemoryStream();
        using(var bw=new BinaryWriter(ms,System.Text.Encoding.UTF8,leaveOpen:true)){int dl=n*2;bw.Write((uint)0x46464952);bw.Write(36+dl);bw.Write((uint)0x45564157);bw.Write((uint)0x20746D66);bw.Write(16);bw.Write((short)1);bw.Write((short)1);bw.Write(SR);bw.Write(SR*2);bw.Write((short)2);bw.Write((short)16);bw.Write((uint)0x61746164);bw.Write(dl);foreach(var s in sam)bw.Write(s);}
        ms.Position=0; return ms;
    }
}

public static class EntityAudio
{
    [DllImport("winmm.dll",CharSet=CharSet.Auto)]
    static extern int mciSendString(string cmd,IntPtr ret,int retLen,IntPtr hwnd);
    const string A="entity666audio"; static bool _open=false,_playing=false;
    public static void Load(string path){Unload();if(!File.Exists(path))return;if(mciSendString($"open \"{path}\" type mpegvideo alias {A}",IntPtr.Zero,0,IntPtr.Zero)==0){_open=true;SetVolume(0);}}
    public static void Play(){if(!_open||_playing)return;mciSendString($"play {A} repeat",IntPtr.Zero,0,IntPtr.Zero);_playing=true;}
    public static void SetVolume(int vol){if(!_open)return;mciSendString($"setaudio {A} volume to {Math.Clamp(vol,0,1000)}",IntPtr.Zero,0,IntPtr.Zero);}
    public static void Unload(){if(!_open)return;mciSendString($"stop {A}",IntPtr.Zero,0,IntPtr.Zero);mciSendString($"close {A}",IntPtr.Zero,0,IntPtr.Zero);_open=false;_playing=false;}
}

// =============================================================================
//  GAME FORM
// =============================================================================
public class GameForm : Form
{
    const int SW=1280,SH=720,RW=640,RH=360;
    readonly Bitmap    _buf;
    readonly Player    _pl=new();
    readonly PoolMap   _map=new();
    readonly int[][]   _tex;
    readonly int[]     _entTex;
    readonly Entity666 _entity=new();

    bool[]  _keys=new bool[512];
    float   _mdx; bool _captured;
    float   _light=.90f,_flickT=.90f,_flickC=.90f,_flickTimer;
    readonly Random _rng=new();
    PoolZone _zone=PoolZone.Deck; float _zAlpha=1f;

    // Entity
    float _entitySpawnTimer=15f,_entityDist=999f,_caughtFlash=0f;
    bool  _spawnWarned=false;
    int   _lastEntityVol=-1;

    // プール落下
    bool  _inPool=false;
    float _poolRespTimer=0f,_poolEffect=0f,_poolImmunity=0f;

    static readonly string[] MSGS={"the pool has been drained.","no one has swum here in years.","the lane markers go on forever.","your footsteps echo.","the chlorine smell never goes away.","the lights never turn off.","the changing rooms are empty.","the water is 80 degrees.","lane 4 is closed for maintenance.","no running on the pool deck.","the deep end goes down 15 feet.","the bottom drain stares up at you.","you are not supposed to be here.","please do not drink the pool water.","you've been walking for a very long time.","something is in the water.","all pools have been closed indefinitely.",};

    string _msg=""; float _msgAlpha,_msgTimer,_nextMsgIn=45f;
    bool _showMap;
    enum State{Title,FadingIn,Playing} State _state=State.Title; float _fadeAlpha=1f;
    MemoryStream? _audioStream; SoundPlayer? _audio;
    readonly Stopwatch _clock=Stopwatch.StartNew();
    double _lastT; float _totalT,_dist,_prevX,_prevY;

    public GameForm()
    {
        ClientSize=new Size(SW,SH); FormBorderStyle=FormBorderStyle.FixedSingle;
        MaximizeBox=false; Text="POOLS"; BackColor=Color.Black; DoubleBuffered=true;
        _buf=new Bitmap(RW,RH,PixelFormat.Format32bppArgb);
        _tex=TexGen.Build();
        string ep=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Entity666.png");
        if(!File.Exists(ep))ep=Path.Combine(Directory.GetCurrentDirectory(),"Entity666.png");
        _entTex=TexGen.LoadEntityTex(ep);
        string mp3=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Entity666.mp3");
        if(!File.Exists(mp3))mp3=Path.Combine(Directory.GetCurrentDirectory(),"Entity666.mp3");
        EntityAudio.Load(mp3);
        _map.Generate(Math.Abs(Environment.TickCount));
        _pl.Init(_map);
        _prevX=_pl.X;_prevY=_pl.Y;
        KeyDown+=(s,e)=>{int k=(int)e.KeyCode;if((uint)k<512)_keys[k]=true;OnK(e.KeyCode);};
        KeyUp  +=(s,e)=>{int k=(int)e.KeyCode;if((uint)k<512)_keys[k]=false;};
        MouseMove+=OnMM; MouseDown+=(s,e)=>{if(e.Button==MouseButtons.Left&&_state!=State.Title)Cap();};
        Shown+=(s,e)=>Centre();
        var tmr=new System.Windows.Forms.Timer{Interval=1}; tmr.Tick+=Loop; tmr.Start();
    }

    void Cap(){if(_captured)return;_captured=true;Cursor.Hide();Centre();}
    void Uncap(){if(!_captured)return;_captured=false;Cursor.Show();}
    void Centre()=>Cursor.Position=PointToScreen(new Point(SW/2,SH/2));
    void OnMM(object?s,MouseEventArgs e){if(!_captured)return;_mdx+=e.X-SW/2;Centre();}
    void OnK(Keys k){if(k==Keys.Escape){if(_state==State.Title)Application.Exit();else Uncap();}if(k==Keys.M&&_state==State.Playing)_showMap=!_showMap;if(k==Keys.F11)TogFS();if(k==Keys.Enter&&_state==State.Title){_state=State.FadingIn;_fadeAlpha=1f;StartAudio();}}
    void TogFS(){if(WindowState==FormWindowState.Maximized){WindowState=FormWindowState.Normal;FormBorderStyle=FormBorderStyle.FixedSingle;}else{FormBorderStyle=FormBorderStyle.None;WindowState=FormWindowState.Maximized;}}
    void StartAudio(){try{_audioStream=AudioGen.BuildPoolAmbience();_audio=new SoundPlayer(_audioStream);_audio.PlayLooping();}catch{}}
    void ShowMsg(string m){_msg=m;_msgAlpha=1f;_msgTimer=4.5f;}

    void TeleportToDeck()
    {
        int cx=(int)_pl.X,cy=(int)_pl.Y;
        for(int r=1;r<40;r++) for(int dy=-r;dy<=r;dy++) for(int dx=-r;dx<=r;dx++)
        {
            if(Math.Abs(dx)!=r&&Math.Abs(dy)!=r)continue;
            int tx=cx+dx,ty=cy+dy;
            if((uint)tx>=PoolMap.W||(uint)ty>=PoolMap.H)continue;
            if(!_map.IsWall(tx,ty)&&_map.GetZone(tx,ty)==PoolZone.Deck){_pl.X=tx+.5f;_pl.Y=ty+.5f;return;}
        }
        _pl.X=_map.StartX+.5f;_pl.Y=_map.StartY+.5f;
    }

    void DrawPoolEffect(Graphics g)
    {
        if(_poolEffect<=0f)return;
        int a=(int)(_poolEffect*145);
        using var b=new SolidBrush(Color.FromArgb(a,0,45,110));
        g.FillRectangle(b,0,0,SW,SH);
        float wave=(MathF.Sin(_totalT*2.8f)*.3f+.7f)*_poolEffect;
        using var wb=new LinearGradientBrush(new Rectangle(0,0,SW,60),Color.FromArgb((int)(wave*80),100,200,255),Color.Transparent,90f);
        g.FillRectangle(wb,0,0,SW,60);
        if(_inPool){int secs=(int)Math.Ceiling(_poolRespTimer);using var cf=new Font("Courier New",12f);using var cb=new SolidBrush(Color.FromArgb((int)(_poolEffect*180),150,210,255));string txt=$"surfacing in {secs}...";float tw=g.MeasureString(txt,cf).Width;g.DrawString(txt,cf,cb,(SW-tw)/2f,SH/2f+100f);}
    }

    void Loop(object?s,EventArgs e)
    {
        double now=_clock.Elapsed.TotalSeconds;
        float dt=(float)Math.Min(now-_lastT,.05f);_lastT=now;_totalT+=dt;
        switch(_state){
            case State.FadingIn:_fadeAlpha=Math.Max(0f,_fadeAlpha-dt*1.4f);if(_fadeAlpha<=0){_state=State.Playing;Cap();}break;
            case State.Playing:Update(dt);break;
        }
        Invalidate();
    }

    void Update(float dt)
    {
        _pl.Update(dt,_keys,_mdx,_map);_mdx=0;
        float dx2=_pl.X-_prevX,dy2=_pl.Y-_prevY;
        _dist+=MathF.Sqrt(dx2*dx2+dy2*dy2);_prevX=_pl.X;_prevY=_pl.Y;
        var nz=_map.GetZone(_pl.X,_pl.Y);
        if(nz!=_zone){_zone=nz;_zAlpha=0f;}
        if(_zAlpha<1f)_zAlpha=Math.Min(1f,_zAlpha+dt*.35f);

        // プール落下
        if(_poolImmunity>0f)_poolImmunity-=dt;
        bool onPool=(nz==PoolZone.Basin||nz==PoolZone.Deep);
        if(onPool&&!_inPool&&_poolImmunity<=0f){_inPool=true;_poolRespTimer=5f;ShowMsg(nz==PoolZone.Deep?"you fall into the deep end.":"splash.");}
        if(!onPool&&_poolImmunity<=0f)_inPool=false;
        if(_inPool){_poolEffect=Math.Min(1f,_poolEffect+dt*2.5f);_poolRespTimer-=dt;if(_poolRespTimer<=0f){TeleportToDeck();_inPool=false;_poolImmunity=2.5f;ShowMsg("you climb back onto the deck.");}}
        else _poolEffect=Math.Max(0f,_poolEffect-dt*3f);
        _pl.EyeOffset=_poolEffect*0.42f;

        Flicker(dt);MsgUpdate(dt);

        // Entity
        _entitySpawnTimer-=dt;
        if(!_entity.Active&&_entitySpawnTimer<=0f){_entity.Spawn(_map,_pl.X,_pl.Y,_rng);if(!_spawnWarned){_spawnWarned=true;ShowMsg(_entity.DistTo(_pl.X,_pl.Y)<35f?"something is close.":"you hear something.");}}
        if(_entity.Active)
        {
            _entity.Update(dt,_map,_pl.X,_pl.Y);
            _entityDist=_entity.DistTo(_pl.X,_pl.Y);
            EntityAudio.Play();
            float t2=Math.Max(0f,1f-Math.Min(_entityDist,25f)/25f);
            int vol=(int)(t2*t2*950);
            if(Math.Abs(vol-_lastEntityVol)>6){EntityAudio.SetVolume(vol);_lastEntityVol=vol;}
            if(_entityDist<1.1f){_caughtFlash=1.0f;ShowMsg("it found you.");_entity.Spawn(_map,_pl.X,_pl.Y,_rng);}
        }
        else if(_lastEntityVol!=0){EntityAudio.SetVolume(0);_lastEntityVol=0;}
        if(_caughtFlash>0f)_caughtFlash=Math.Max(0f,_caughtFlash-dt*1.1f);
    }

    void Flicker(float dt){float lb=Atmos.Get(_zone).LightBase;_flickTimer-=dt;if(_flickTimer<=0f){_flickTimer=(float)(_rng.NextDouble()*.20+.04);_flickT=_rng.Next(100)<4?(float)(_rng.NextDouble()*.38+.08):(float)(_rng.NextDouble()*.18+.82)*lb;}_flickC=_flickC*.74f+_flickT*.26f;_light=_flickC;}
    void MsgUpdate(float dt){if(_msgAlpha>0f){_msgTimer-=dt;if(_msgTimer<=0f)_msgAlpha=Math.Max(0f,_msgAlpha-dt*.7f);}_nextMsgIn-=dt;if(_nextMsgIn<=0f){_nextMsgIn=(float)(_rng.NextDouble()*85+30);ShowMsg(MSGS[_rng.Next(MSGS.Length)]);}}

    protected override void OnPaint(PaintEventArgs e)
    {
        var g=e.Graphics;
        if(_state==State.Title){DrawTitle(g);return;}
        var bd=_buf.LockBits(new Rectangle(0,0,RW,RH),ImageLockMode.WriteOnly,PixelFormat.Format32bppArgb);
        unsafe{Raycaster.Render((int*)bd.Scan0,RW,RH,_pl,_map,_tex,_entTex,_light,_totalT,_zone,_entity);}
        _buf.UnlockBits(bd);
        g.InterpolationMode=InterpolationMode.NearestNeighbor;
        g.PixelOffsetMode=System.Drawing.Drawing2D.PixelOffsetMode.Half;
        g.DrawImage(_buf,0,0,SW,SH);
        DrawVignette(g);DrawEntityAura(g);
        if(_poolEffect>0f)DrawPoolEffect(g);
        if(_msgAlpha>0f)DrawMsg(g);
        DrawHUD(g);
        if(_showMap)DrawMinimap(g);
        if(_caughtFlash>0f){Color fc=_caughtFlash>.5f?Color.FromArgb((int)((_caughtFlash-.5f)*2*225),255,255,255):Color.FromArgb((int)(_caughtFlash*2*160),160,0,0);using var fb=new SolidBrush(fc);g.FillRectangle(fb,0,0,SW,SH);}
        if(_fadeAlpha>0f){using var fb=new SolidBrush(Color.FromArgb((int)(_fadeAlpha*255),0,0,0));g.FillRectangle(fb,0,0,SW,SH);}
    }

    void DrawVignette(Graphics g)
    {
        const int V=210;
        using(var b=new LinearGradientBrush(new Rectangle(0,0,SW,V),Color.FromArgb(175,0,0,0),Color.Transparent,90f))g.FillRectangle(b,0,0,SW,V);
        using(var b=new LinearGradientBrush(new Rectangle(0,SH-V,SW,V),Color.Transparent,Color.FromArgb(175,0,0,0),90f))g.FillRectangle(b,0,SH-V,SW,V);
        using(var b=new LinearGradientBrush(new Rectangle(0,0,V,SH),Color.FromArgb(140,0,0,0),Color.Transparent,0f))g.FillRectangle(b,0,0,V,SH);
        using(var b=new LinearGradientBrush(new Rectangle(SW-V,0,V,SH),Color.Transparent,Color.FromArgb(140,0,0,0),0f))g.FillRectangle(b,SW-V,0,V,SH);
    }
    void DrawEntityAura(Graphics g)
    {
        if(!_entity.Active||_entityDist>20f)return;
        float t2=Math.Max(0f,1f-_entityDist/20f);
        float pulse=(MathF.Sin(_totalT*(1.5f+t2*4f)*2*MathF.PI)*.35f+.65f);
        int alpha=(int)(t2*t2*pulse*215);if(alpha<=0)return;
        int V=(int)(80+t2*130);
        using(var b=new LinearGradientBrush(new Rectangle(0,0,SW,V),Color.FromArgb(alpha,188,0,0),Color.Transparent,90f))g.FillRectangle(b,0,0,SW,V);
        using(var b=new LinearGradientBrush(new Rectangle(0,SH-V,SW,V),Color.Transparent,Color.FromArgb(alpha,188,0,0),90f))g.FillRectangle(b,0,SH-V,SW,V);
        using(var b=new LinearGradientBrush(new Rectangle(0,0,V,SH),Color.FromArgb(alpha,168,0,0),Color.Transparent,0f))g.FillRectangle(b,0,0,V,SH);
        using(var b=new LinearGradientBrush(new Rectangle(SW-V,0,V,SH),Color.Transparent,Color.FromArgb(alpha,168,0,0),0f))g.FillRectangle(b,SW-V,0,V,SH);
    }
    void DrawMsg(Graphics g)
    {
        int a=(int)(_msgAlpha*210);
        bool em=_msg.Contains("found")||_msg.Contains("close")||_msg.Contains("hear")||_msg.Contains("something")||_msg.Contains("splash")||_msg.Contains("fall");
        using var font=new Font("Courier New",16f);
        var sz=g.MeasureString(_msg,font); float tx=(SW-sz.Width)/2f,ty=SH-145f;
        using var sh=new SolidBrush(Color.FromArgb((int)(_msgAlpha*140),0,0,0));
        using var br=new SolidBrush(em?Color.FromArgb(a,240,75,75):Color.FromArgb(a,190,215,230));
        g.DrawString(_msg,font,sh,tx+2,ty+2);g.DrawString(_msg,font,br,tx,ty);
    }
    void DrawHUD(Graphics g)
    {
        using var f=new Font("Courier New",9f);
        int za=(int)(Math.Min(_zAlpha*3f,1f)*82);
        using var zb=new SolidBrush(Color.FromArgb(za,180,210,230));
        g.DrawString($"[ {_zone.ToString().ToUpper()} ]",f,zb,18,SH-30);
        g.DrawString($"{_dist*2.2f:0.0} m",f,zb,18,SH-44);
        float cr=_entity.Active?Math.Max(0f,1f-_entityDist/15f):0f;
        using var cp=new Pen(Color.FromArgb(65,(int)(200+cr*55),(int)(230-cr*230),(int)(255-cr*255)),1f);
        g.DrawLine(cp,SW/2-7,SH/2,SW/2+7,SH/2);g.DrawLine(cp,SW/2,SH/2-7,SW/2,SH/2+7);
        if(_zAlpha<.65f){float fade=1f-_zAlpha/.65f;using var zf=new Font("Courier New",18f);using var zfb=new SolidBrush(Color.FromArgb((int)(fade*180),180,215,235));string zn=_zone.ToString().ToUpper();float fw=g.MeasureString(zn,zf).Width;g.DrawString(zn,zf,zfb,(SW-fw)/2f,SH/2f+75f);}
        if(_totalT<13f){float fade=_totalT<9f?1f:(13f-_totalT)/4f;using var hf=new Font("Courier New",10f);using var hfb=new SolidBrush(Color.FromArgb((int)(fade*88),170,205,225));const string hint="WASD / Arrows: Move   Mouse: Look   M: Map   ESC: Release Mouse";float hw=g.MeasureString(hint,hf).Width;g.DrawString(hint,hf,hfb,(SW-hw)/2f,20f);}
    }
    void DrawMinimap(Graphics g)
    {
        const int SZ=160,CS=3;int rad=SZ/2/CS,mx=SW-SZ-16,my=16,px=(int)_pl.X,py=(int)_pl.Y;
        using var bg=new SolidBrush(Color.FromArgb(135,0,0,0));g.FillRectangle(bg,mx,my,SZ,SZ);
        for(int dy=-rad;dy<=rad;dy++) for(int dx=-rad;dx<=rad;dx++){
            int wx=px+dx,wy=py+dy;if(_map.GetCell(wx,wy)==0)continue;
            PoolZone cz=(uint)wx<PoolMap.W&&(uint)wy<PoolMap.H?(PoolZone)_map.Zones[wx,wy]:PoolZone.Deck;
            Color c=cz switch{PoolZone.Deck=>Color.FromArgb(165,180,188,195),PoolZone.Basin=>Color.FromArgb(165,40,108,175),PoolZone.Walkway=>Color.FromArgb(165,160,168,172),PoolZone.Changing=>Color.FromArgb(165,175,162,145),PoolZone.Deep=>Color.FromArgb(165,12,28,70),_=>Color.FromArgb(165,100,100,100)};
            // ベンチ(type2)は茶色で表示
            if(_map.GetCell(wx,wy)==2)c=Color.FromArgb(165,120,85,45);
            using var wb=new SolidBrush(c);g.FillRectangle(wb,mx+(dx+rad)*CS,my+(dy+rad)*CS,CS,CS);
        }
        int psx=mx+rad*CS+1,psy=my+rad*CS+1;
        using var pd=new SolidBrush(Color.White);g.FillRectangle(pd,psx-1,psy-1,3,3);
        using var dp=new Pen(Color.FromArgb(210,220,238,255),1.5f);g.DrawLine(dp,psx,psy,psx+(int)(Math.Cos(_pl.Angle)*7),psy+(int)(Math.Sin(_pl.Angle)*7));
        if(_entity.Active){int ex=(int)(_entity.X-_pl.X),ey=(int)(_entity.Y-_pl.Y);if(Math.Abs(ex)<=rad&&Math.Abs(ey)<=rad){float pulse=MathF.Sin(_totalT*4f)*.3f+.7f;int esx=mx+(ex+rad)*CS,esy=my+(ey+rad)*CS;using var eb=new SolidBrush(Color.FromArgb((int)(pulse*225),230,18,18));g.FillEllipse(eb,esx-3,esy-3,6,6);using var ep=new Pen(Color.FromArgb((int)(pulse*140),255,55,55),1f);g.DrawEllipse(ep,esx-5,esy-5,10,10);}}
        using var bp=new Pen(Color.FromArgb(85,150,190,220),1f);g.DrawRectangle(bp,mx,my,SZ,SZ);
    }
    void DrawTitle(Graphics g)
    {
        double p=Math.Sin(_totalT*.4)*.5+.5;g.Clear(Color.FromArgb((int)(4+p*3),(int)(8+p*5),(int)(18+p*8)));
        for(int y=0;y<SH;y+=40)for(int x=0;x<SW;x+=40){float c=(float)(Math.Sin(x*.04+_totalT*1.2)*Math.Cos(y*.04+_totalT*.9)*.5+.5);using var nb=new SolidBrush(Color.FromArgb((int)(c*12),40,100,180));g.FillEllipse(nb,x-20,y-20,80,80);}
        using var tF=new Font("Courier New",72f,FontStyle.Bold);using var sF=new Font("Courier New",15f);using var hF=new Font("Courier New",12f);using var cF=new Font("Courier New",10f);
        float hp=(float)(Math.Sin(_totalT*1.9)*.35+.65);
        using var tb=new SolidBrush(Color.FromArgb(180,218,238));using var sb=new SolidBrush(Color.FromArgb(98,145,175));using var hb=new SolidBrush(Color.FromArgb((int)(hp*215),140,190,220));using var cb=new SolidBrush(Color.FromArgb(60,120,165,195));
        Ctr(g,"POOLS",tF,tb,SH/2f-115f);Ctr(g,"there is no one here but you",sF,sb,SH/2f+15f);Ctr(g,"[ press enter ]",hF,hb,SH/2f+78f);Ctr(g,"WASD / Arrows: Move   Mouse: Look   M: Minimap   F11: Fullscreen",cF,cb,SH-54f);
        using var rp=new Pen(Color.FromArgb(35,100,155,195),1f);g.DrawLine(rp,SW*.15f,SH/2f-2f,SW*.85f,SH/2f-2f);
    }
    static void Ctr(Graphics g,string s,Font f,Brush b,float y){float w=g.MeasureString(s,f).Width;g.DrawString(s,f,b,(SW-w)/2f,y);}
    protected override void OnFormClosing(FormClosingEventArgs e){Uncap();_audio?.Stop();_audio?.Dispose();_audioStream?.Dispose();EntityAudio.Unload();base.OnFormClosing(e);}
}

// =============================================================================
//  ENTRY POINT
// =============================================================================
static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new GameForm());
    }
}
